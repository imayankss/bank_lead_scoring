# src/ml/model_select.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import lightgbm as lgb

from src.ml.evaluation import evaluate_binary_classifier, ClassificationMetrics


@dataclass
class CandidateModelResult:
    """Simple container for one candidate's fitted model and metrics."""
    name: str
    model: object
    metrics: ClassificationMetrics


def get_candidate_models(random_state: int = 42) -> Dict[str, object]:
    """
    Define all models you want to compare.
    You can remove/add models as needed; this is just an example.
    """
    models: Dict[str, object] = {
        "logistic_regression": LogisticRegression(
            solver="lbfgs",
            max_iter=1000,
            class_weight="balanced",
            n_jobs=-1,
        ),
        "random_forest": RandomForestClassifier(
            n_estimators=300,
            max_depth=None,
            min_samples_split=10,
            min_samples_leaf=5,
            class_weight="balanced",
            random_state=random_state,
            n_jobs=-1,
        ),
        "lightgbm_unified": lgb.LGBMClassifier(
            n_estimators=500,
            learning_rate=0.05,
            max_depth=-1,
            subsample=0.8,
            colsample_bytree=0.8,
            objective="binary",
            class_weight="balanced",
            random_state=random_state,
            n_jobs=-1,
        ),
    }
    return models


def _select_best_index(
    metrics_df: pd.DataFrame,
    selection_metric: str,
    min_recall: float | None = None,
) -> int:
    """
    Helper: choose the row index of the 'best' model.
    selection_metric: 'auc_roc' or 'recall'
    min_recall: optional floor; if set and selection_metric='auc_roc',
                we will only consider models with recall >= min_recall.
    """
    if selection_metric not in {"auc_roc", "recall"}:
        raise ValueError(f"selection_metric must be 'auc_roc' or 'recall', got {selection_metric!r}")

    df = metrics_df.copy()

    if selection_metric == "auc_roc" and min_recall is not None:
        eligible = df["recall"] >= min_recall
        if eligible.any():
            df = df[eligible]
        # if none passes min_recall, we fall back to all models

    best_idx = int(df[selection_metric].idxmax())
    return best_idx


def train_and_select_model(
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_valid: pd.DataFrame,
    y_valid: pd.Series,
    threshold: float = 0.5,
    selection_metric: str = "auc_roc",
    min_recall: float | None = None,
    random_state: int = 42,
    metrics_output_path: str | None = None,
) -> Tuple[str, object, pd.DataFrame]:
    """
    Train all candidate models, evaluate them using evaluate_binary_classifier,
    and return the best model.

    Parameters
    ----------
    X_train, y_train : training set
    X_valid, y_valid : validation set used for model comparison
    threshold        : probability threshold for binary classification
    selection_metric : 'auc_roc' (default) or 'recall'
    min_recall       : optional minimum recall when selection_metric='auc_roc'
    random_state     : random seed for candidate models
    metrics_output_path : if provided, save the metrics table to CSV here

    Returns
    -------
    champion_name : str          -> name of best model (e.g. 'lightgbm_unified')
    champion_model: fitted model -> you can save this with joblib
    metrics_df    : pd.DataFrame -> one row per candidate, with metrics
    """
    candidates = get_candidate_models(random_state=random_state)

    results: List[CandidateModelResult] = []

    print("\n================ Model Selection – Candidates ================")
    print(f"Selection metric: {selection_metric}, threshold={threshold:.2f}")
    if min_recall is not None and selection_metric == "auc_roc":
        print(f"Minimum recall constraint: {min_recall:.2f}")

    for name, model in candidates.items():
        print(f"\n--- Training candidate model: {name} ---")
        model.fit(X_train, y_train)

        # Predict probabilities on validation set
        y_valid_proba = model.predict_proba(X_valid)

        # We don't want 3 ROC plots, so disable here
        metrics, _cm = evaluate_binary_classifier(
            y_true=y_valid.values,
            y_proba=y_valid_proba,
            threshold=threshold,
            plot_roc=False,
            title_prefix=f"{name} – Validation",
        )

        results.append(CandidateModelResult(name=name, model=model, metrics=metrics))

    # Build metrics table
    records = []
    for r in results:
        row = {"model_name": r.name}
        row.update(r.metrics.as_dict())
        records.append(row)

    metrics_df = pd.DataFrame.from_records(records)

    print("\n================ All Candidate Metrics ================")
    print(metrics_df.to_string(index=False))

    # Choose champion index
    best_idx = _select_best_index(
        metrics_df=metrics_df,
        selection_metric=selection_metric,
        min_recall=min_recall,
    )
    champion_row = metrics_df.iloc[best_idx]
    champion_name = str(champion_row["model_name"])
    champion_model = next(r.model for r in results if r.name == champion_name)

    print("\n================ Champion Model Selected ================")
    print(f"Champion model: {champion_name}")
    print(
        f"Accuracy={champion_row['accuracy']:.4f}, "
        f"AUC={champion_row['auc_roc']:.4f}, "
        f"Precision={champion_row['precision']:.4f}, "
        f"Recall={champion_row['recall']:.4f}"
    )

    # Optionally save metrics
    if metrics_output_path is not None:
        metrics_df.to_csv(metrics_output_path, index=False)
        print(f"\nMetrics written to: {metrics_output_path}")

    # Optionally: plot ROC for champion only
    print("\nPlotting ROC curve for champion model only...")
    y_valid_proba_champion = champion_model.predict_proba(X_valid)
    evaluate_binary_classifier(
        y_true=y_valid.values,
        y_proba=y_valid_proba_champion,
        threshold=threshold,
        plot_roc=True,
        title_prefix=f"{champion_name} – Validation (Champion)",
    )

    return champion_name, champion_model, metrics_df


