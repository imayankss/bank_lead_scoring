#!/usr/bin/env python
"""
End-to-end synthetic dataset scaler:
- Expands customers from N (~482) to target (e.g., 1000)
- Enforces constraints on new users (age 18–38, monthly income > 20,000)
- Preserves distributions by donor-based bootstrapping + jitter
- Expands core accounts & core transactions proportionally
- Updates AA bank mapping (Anchor->Bank of India, etc.) and adds Kotak
- Expands AA customers, AA accounts, AA transactions, and mart_customer_360_aa
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd

# ----------------------------------------------------------------------
# Utility helpers
# ----------------------------------------------------------------------


def _load_csv(path: Path, required: bool = True) -> pd.DataFrame | None:
    if not path.exists():
        if required:
            print(f"[ERROR] Required file not found: {path}", file=sys.stderr)
            sys.exit(1)
        else:
            print(f"[WARN] Optional file not found, skipping: {path}")
            return None
    print(f"[INFO] Loading {path}")
    return pd.read_csv(path)


def _save_csv(df: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    print(f"[INFO] Saving {path} ({len(df):,} rows)")
    df.to_csv(path, index=False)


def _rng(seed: int = 42) -> np.random.Generator:
    return np.random.default_rng(seed)


# ----------------------------------------------------------------------
# BLOCK A: Customer expansion
#   - Expand schema_customer_master to target number of users
#   - New users: age 18–38, monthly income > 20,000 (annual >= 240,000)
# ----------------------------------------------------------------------


def generate_unique_string_ids(
    existing: pd.Series, prefix: str, width: int
) -> tuple[dict, int]:
    """
    Utility to generate sequential IDs with given prefix and zero-padded width.
    Returns: (mapping_dict, max_index_after)
    """
    out = {}
    max_num = 0
    for v in existing.dropna().unique():
        try:
            n = int(str(v).replace(prefix, ""))
            if n > max_num:
                max_num = n
        except ValueError:
            continue
    return out, max_num


def _generate_aadhaar(existing: pd.Series, n: int, rng: np.random.Generator) -> list[str]:
    used = set(str(x) for x in existing.dropna().astype(str))
    res = []
    while len(res) < n:
        val = "".join(rng.choice(list("0123456789"), size=12))
        if val not in used:
            used.add(val)
            res.append(val)
    return res


def _generate_pan(existing: pd.Series, n: int, rng: np.random.Generator) -> list[str]:
    used = set(str(x) for x in existing.dropna().astype(str))
    letters = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    digits = list("0123456789")
    res = []
    while len(res) < n:
        val = (
            "".join(rng.choice(letters, size=5))
            + "".join(rng.choice(digits, size=4))
            + rng.choice(letters)
        )
        if val not in used:
            used.add(val)
            res.append(val)
    return res


def _generate_phone(existing: pd.Series, n: int, rng: np.random.Generator) -> list[str]:
    used = set(str(x) for x in existing.dropna().astype(str))
    first_digits = list("6789")
    digits = list("0123456789")
    res = []
    while len(res) < n:
        val = rng.choice(first_digits) + "".join(rng.choice(digits, size=9))
        if val not in used:
            used.add(val)
            res.append(val)
    return res


def _generate_email(existing: pd.Series, base_names: list[str], rng: np.random.Generator) -> list[str]:
    used = set(str(x) for x in existing.dropna().astype(str))
    res = []
    domains = ["example.com", "mail.com", "bankuser.in"]
    for base in base_names:
        trials = 0
        while True:
            suffix = rng.integers(10, 9999)
            domain = rng.choice(domains)
            val = f"{base.lower().replace(' ', '.')}{suffix}@{domain}"
            if val not in used:
                used.add(val)
                res.append(val)
                break
            trials += 1
            if trials > 50:
                # fallback
                val = f"user{rng.integers(100000, 999999)}@{domain}"
                if val not in used:
                    used.add(val)
                    res.append(val)
                    break
    return res


def expand_customers(
    df: pd.DataFrame,
    target_n: int = 1000,
    min_age: int = 18,
    max_age: int = 38,
    min_monthly_income: int = 20000,
    random_state: int = 42,
) -> pd.DataFrame:
    rng = _rng(random_state)
    df = df.copy()
    n_current = df["cust_id"].nunique()
    print(f"[INFO] Current customers: {n_current}, target: {target_n}")
    if n_current >= target_n:
        print("[INFO] No expansion needed for customers.")
        return df

    n_new = target_n - n_current
    print(f"[INFO] Need to create {n_new} new customers")

    # donors
    min_annual = min_monthly_income * 12
    if "income_annual_inr" not in df.columns:
        raise ValueError("schema_customer_master must have 'income_annual_inr' column")

    donors = df[
        df["age"].between(min_age, max_age) & (df["income_annual_inr"] >= min_annual)
    ].reset_index(drop=True)
    if donors.empty:
        raise ValueError(
            "No donor customers satisfy the age/income constraints; "
            "cannot expand with given rules."
        )
    print(f"[INFO] Donor pool size: {len(donors)}")

    # determine current max cust_id, cif_id
    max_cust_num = 0
    for v in df["cust_id"].astype(str).unique():
        try:
            max_cust_num = max(max_cust_num, int(v[1:]))
        except ValueError:
            continue

    max_cif_num = 0
    if "cif_id" in df.columns:
        for v in df["cif_id"].astype(str).unique():
            try:
                max_cif_num = max(max_cif_num, int(v[3:]))
            except ValueError:
                continue

    print(f"[INFO] max cust_num: {max_cust_num}, max cif_num: {max_cif_num}")

    new_rows = []
    for i in range(1, n_new + 1):
        d = donors.iloc[rng.integers(0, len(donors))]
        cust_num = max_cust_num + i
        cif_num = max_cif_num + i

        row = d.copy()

        # age jitter
        age_new = d["age"] + rng.normal(0, 2.5)
        age_new = int(np.clip(round(age_new), min_age, max_age))
        row["age"] = age_new

        # income jitter (ensure ≥ min_annual)
        mult = rng.lognormal(mean=0.0, sigma=0.15)
        income_new = max(min_annual, d["income_annual_inr"] * mult)
        row["income_annual_inr"] = income_new

        # recompute segment
        if income_new < 200_000:
            seg = "LOW"
        elif income_new < 1_000_000:
            seg = "MID"
        else:
            seg = "HIGH"
        if "income_segment" in row.index:
            row["income_segment"] = seg

        # credit score jitter
        if "credit_score" in row.index:
            credit_new = int(np.clip(d["credit_score"] + rng.normal(0, 30), 300, 900))
            row["credit_score"] = credit_new

        row["cust_id"] = f"C{cust_num:05d}"
        if "cif_id" in row.index:
            row["cif_id"] = f"CIF{cif_num:08d}"

        new_rows.append(row)

    df_new = pd.concat([df, pd.DataFrame(new_rows)], ignore_index=True)

    # Generate new Aadhaar/PAN/phone/email for new rows if columns exist
    original_ids = set(df["cust_id"])
    mask_new = df_new["cust_id"].isin(
        {f"C{max_cust_num + i:05d}" for i in range(1, n_new + 1)}
    )
    idx_new = df_new.index[mask_new]

    print("[INFO] Generating identity/contact fields for new customers")
    if "aadhaar_no" in df_new.columns:
        df_new.loc[mask_new, "aadhaar_no"] = _generate_aadhaar(
            df_new["aadhaar_no"], n_new, rng
        )
    if "pan_no" in df_new.columns:
        df_new.loc[mask_new, "pan_no"] = _generate_pan(df_new["pan_no"], n_new, rng)
    if "phone" in df_new.columns:
        df_new.loc[mask_new, "phone"] = _generate_phone(
            df_new["phone"], n_new, rng
        )
    if "email" in df_new.columns:
        # build base names from name columns if present
        if {"first_name", "last_name"}.issubset(df_new.columns):
            bases = (
                df_new.loc[mask_new, "first_name"]
                + " "
                + df_new.loc[mask_new, "last_name"]
            ).tolist()
        elif "full_name" in df_new.columns:
            bases = df_new.loc[mask_new, "full_name"].tolist()
        else:
            bases = [f"user{i}" for i in range(1, n_new + 1)]
        emails = _generate_email(df_new["email"], bases, rng)
        df_new.loc[mask_new, "email"] = emails

    print(f"[INFO] Expanded customers to {df_new['cust_id'].nunique()} rows")
    return df_new


# ----------------------------------------------------------------------
# BLOCK B: Core account expansion (general_acct_mast_table + ans_acc_car)
# ----------------------------------------------------------------------


def expand_core_accounts(
    acct_df: pd.DataFrame,
    customers_before: set[str],
    customers_after: set[str],
    random_state: int = 42,
) -> tuple[pd.DataFrame, dict[str, list[str]]]:
    """
    Expand prod_ods_cbsind_general_acct_mast_table for new customers.

    Returns:
      expanded_accounts_df,
      new_acid_map: dict[cust_id] -> list of new acid strings
    """
    rng = _rng(random_state)
    acct_df = acct_df.copy()

    new_cust_ids = sorted(list(customers_after - customers_before))
    if not new_cust_ids:
        print("[INFO] No new customers; skipping account expansion.")
        return acct_df, {}

    print(f"[INFO] Expanding accounts for {len(new_cust_ids)} new customers")

    # accounts per customer distribution
    if "cust_id" not in acct_df.columns or "acid" not in acct_df.columns:
        raise ValueError("Account table must have columns 'cust_id' and 'acid'")

    counts = acct_df.groupby("cust_id")["acid"].nunique()
    probs = counts.value_counts(normalize=True).sort_index()

    # helper: sample how many accounts for a new customer
    possible_k = probs.index.to_numpy()
    prob_k = probs.to_numpy()

    # determine max acid number for ID continuation
    max_acid_num = 0
    for v in acct_df["acid"].astype(str).unique():
        if v.startswith("A"):
            try:
                max_acid_num = max(max_acid_num, int(v[1:]))
            except ValueError:
                continue

    new_rows = []
    new_acid_map: dict[str, list[str]] = {cid: [] for cid in new_cust_ids}

    for cid in new_cust_ids:
        # choose how many accounts
        k = int(rng.choice(possible_k, p=prob_k))
        # choose a donor customer to mimic structure
        donor_cust = counts.sample(1, random_state=int(rng.integers(0, 1e9))).index[0]
        donor_accounts = acct_df[acct_df["cust_id"] == donor_cust]

        donor_sample = (
            donor_accounts.sample(
                n=min(k, len(donor_accounts)), replace=len(donor_accounts) < k, random_state=int(rng.integers(0, 1e9))
            )
            .reset_index(drop=True)
        )

        for _idx, d in donor_sample.iterrows():
            max_acid_num += 1
            new_acid = f"A{max_acid_num:07d}"
            row = d.copy()
            row["cust_id"] = cid
            row["acid"] = new_acid

            # account number (foracid) if present
            if "foracid" in row.index:
                row["foracid"] = f"{rng.integers(10**11, 10**12 - 1)}"

            # open date jitter if present
            if "acct_opn_date" in row.index:
                try:
                    base = pd.to_datetime(d["acct_opn_date"])
                    offset = int(rng.integers(-180, 180))
                    row["acct_opn_date"] = (base + pd.Timedelta(days=offset)).date()
                except Exception:
                    pass

            # balances: small multiplicative noise if present
            for col in ["clr_bal_amt", "sanct_lim"]:
                if col in row.index:
                    val = float(row[col])
                    mult = rng.lognormal(mean=0, sigma=0.25)
                    row[col] = max(0.0, val * mult)

            new_rows.append(row)
            new_acid_map[cid].append(new_acid)

    acct_expanded = pd.concat([acct_df, pd.DataFrame(new_rows)], ignore_index=True)
    print(f"[INFO] Accounts expanded to {len(acct_expanded):,} rows")
    return acct_expanded, new_acid_map


def expand_ans_acc_car(
    acc_car_df: pd.DataFrame,
    customers_before: set[str],
    customers_after: set[str],
    random_state: int = 42,
) -> pd.DataFrame:
    """
    Expand ans_acc_car per-customer balance proxy.
    """
    rng = _rng(random_state)
    acc_car_df = acc_car_df.copy()

    if "cust_id" not in acc_car_df.columns:
        print("[WARN] ans_acc_car missing 'cust_id'; skipping its expansion.")
        return acc_car_df

    new_cust_ids = sorted(list(customers_after - customers_before))
    if not new_cust_ids:
        print("[INFO] No new customers; skipping ans_acc_car expansion.")
        return acc_car_df

    print(f"[INFO] Expanding ans_acc_car for {len(new_cust_ids)} new customers")

    donors = acc_car_df[acc_car_df["cust_id"].isin(customers_before)]
    if donors.empty:
        print("[WARN] No donors in ans_acc_car; skipping.")
        return acc_car_df

    new_rows = []
    for cid in new_cust_ids:
        d = donors.iloc[rng.integers(0, len(donors))].copy()
        d["cust_id"] = cid

        for col in ["avg_bal_12m_td", "avg_bal_12m_savings", "avg_bal_12m_current_ac"]:
            if col in d.index:
                base = float(d[col])
                mult = rng.lognormal(mean=0, sigma=0.3)
                d[col] = max(0.0, base * mult)

        new_rows.append(d)

    acc_car_expanded = pd.concat([acc_car_df, pd.DataFrame(new_rows)], ignore_index=True)
    print(f"[INFO] ans_acc_car expanded to {len(acc_car_expanded):,} rows")
    return acc_car_expanded


# ----------------------------------------------------------------------
# BLOCK C: Core CBS transactions expansion (hist_tran_dtl)
# ----------------------------------------------------------------------


def expand_hist_tran(
    hist_df: pd.DataFrame,
    acct_df_original: pd.DataFrame,
    acct_df_expanded: pd.DataFrame,
    new_acid_map: dict[str, list[str]],
    random_state: int = 42,
) -> pd.DataFrame:
    """
    Expand prod_ods_cbsind_hist_tran_dtl_table for new accounts.
    """
    rng = _rng(random_state)
    hist_df = hist_df.copy()

    if "acid" not in hist_df.columns:
        print("[WARN] hist_tran_dtl missing 'acid'; skipping transaction expansion.")
        return hist_df

    # gather original vs new acids
    original_acids = set(acct_df_original["acid"].astype(str).unique())
    expanded_acids = set(acct_df_expanded["acid"].astype(str).unique())
    new_acids = sorted(list(expanded_acids - original_acids))
    if not new_acids:
        print("[INFO] No new accounts; skipping hist_tran expansion.")
        return hist_df

    print(f"[INFO] Expanding hist_tran_dtl for {len(new_acids)} new accounts")

    # map acid -> cust_id (from expanded accounts)
    acid_to_cust = {
        str(row["acid"]): str(row["cust_id"])
        for _, row in acct_df_expanded[["acid", "cust_id"]].iterrows()
    }

    # donors grouped by acid
    donors_by_acid = {acid: g for acid, g in hist_df.groupby("acid")}

    new_rows = []
    for new_acid in new_acids:
        # choose a donor acid
        donor_acid = rng.choice(list(donors_by_acid.keys()))
        donor_txn = donors_by_acid[donor_acid]

        # choose date shift if tran_date exists
        if "tran_date" in donor_txn.columns:
            try:
                base_dates = pd.to_datetime(donor_txn["tran_date"])
                shift_days = int(rng.integers(-90, 90))
                new_dates = (base_dates + pd.to_timedelta(shift_days, unit="D")).dt.date
            except Exception:
                new_dates = donor_txn["tran_date"]
        else:
            new_dates = donor_txn.get("tran_date", None)

        for idx, d in donor_txn.reset_index(drop=True).iterrows():
            row = d.copy()
            row["acid"] = new_acid
            cust_id = acid_to_cust.get(str(new_acid))
            if cust_id and "cust_id" in row.index:
                row["cust_id"] = cust_id

            # update date if present
            if "tran_date" in row.index and new_dates is not None:
                row["tran_date"] = new_dates.iloc[idx]

            # amount jitter
            for col in ["tran_amt", "amount"]:
                if col in row.index:
                    base = float(row[col])
                    mult = rng.lognormal(mean=0, sigma=0.3)
                    row[col] = max(0.0, base * mult)

            # generate new transaction ID if we can
            for id_col, prefix in [("txn_id", "TXN"), ("tran_id", "TRN")]:
                if id_col in row.index:
                    # approximate sequential, based on length of hist_df
                    row[id_col] = f"{prefix}{len(hist_df) + len(new_rows) + 1:09d}"

            new_rows.append(row)

    hist_expanded = pd.concat([hist_df, pd.DataFrame(new_rows)], ignore_index=True)
    print(f"[INFO] hist_tran_dtl expanded to {len(hist_expanded):,} rows")
    return hist_expanded


# ----------------------------------------------------------------------
# BLOCK D: AA bank mapping update (aa_dim_bank)
# ----------------------------------------------------------------------


def update_aa_dim_bank(df: pd.DataFrame) -> pd.DataFrame:
    """
    Replace bank names and add Kotak.
      ANCHOR  -> Bank of India (anchor)
      BANK_A  -> State Bank of India (SBI)
      BANK_B  -> Bank of Baroda
      + KOTAK -> Kotak Bank (competitor)
    """
    df = df.copy()
    if "bank_code" not in df.columns:
        raise ValueError("aa_dim_bank must have 'bank_code' column")

    mapping = {
        "ANCHOR": "Bank of India",
        "BANK_A": "State Bank of India (SBI)",
        "BANK_B": "Bank of Baroda",
    }

    if "bank_name" in df.columns:
        df["bank_name"] = df.apply(
            lambda row: mapping.get(row["bank_code"], row["bank_name"]), axis=1
        )

    if "bank_type" in df.columns:
        # anchor remains anchor; others competitor
        df.loc[df["bank_code"] == "ANCHOR", "bank_type"] = "anchor"
        df.loc[df["bank_code"] != "ANCHOR", "bank_type"] = "competitor"

    # add KOTAK if missing
    if "KOTAK" not in df["bank_code"].values:
        new_row = {
            "bank_code": "KOTAK",
            "bank_name": "Kotak Bank",
        }
        if "bank_type" in df.columns:
            new_row["bank_type"] = "competitor"
        if "country" in df.columns:
            new_row["country"] = "India"

        # ensure all columns present
        for col in df.columns:
            if col not in new_row:
                new_row[col] = np.nan

        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)

    print(f"[INFO] Updated aa_dim_bank with Kotak and renamed banks")
    return df


# ----------------------------------------------------------------------
# BLOCK E: AA customer, account, transaction, and mart_360 expansion
# ----------------------------------------------------------------------


def expand_aa_customers_and_accounts(
    aa_customer_map: pd.DataFrame,
    aa_accounts: pd.DataFrame,
    aa_transactions: pd.DataFrame,
    mart_aa: pd.DataFrame,
    customers_before: set[str],
    customers_after: set[str],
    new_acid_map: dict[str, list[str]],
    random_state: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Expand AA layer by bootstrapping from existing AA customers.
    """
    rng = _rng(random_state)

    aa_customer_map = aa_customer_map.copy()
    aa_accounts = aa_accounts.copy()
    aa_transactions = aa_transactions.copy()
    mart_aa = mart_aa.copy()

    # infer new customer IDs
    new_cust_ids = sorted(list(customers_after - customers_before))
    if not new_cust_ids:
        print("[INFO] No new customers; skipping AA expansion.")
        return aa_customer_map, aa_accounts, aa_transactions, mart_aa

    print(f"[INFO] Expanding AA layer for {len(new_cust_ids)} new customers")

    # existing AA ids
    if "aa_customer_id" not in aa_customer_map.columns:
        print("[WARN] aa_customer_map missing 'aa_customer_id'; skipping AA expansion.")
        return aa_customer_map, aa_accounts, aa_transactions, mart_aa

    max_aa_id = int(aa_customer_map["aa_customer_id"].max())
    print(f"[INFO] max aa_customer_id: {max_aa_id}")

    # donors
    existing_aa_ids = aa_customer_map["aa_customer_id"].unique().tolist()

    # mapping for aa_accounts and aa_transactions
    accounts_by_aa = (
        aa_accounts.groupby("aa_customer_id") if "aa_customer_id" in aa_accounts.columns else {}
    )
    txns_by_aa = (
        aa_transactions.groupby("aa_customer_id")
        if "aa_customer_id" in aa_transactions.columns
        else {}
    )

    # track new IDs mapping
    new_aa_rows = []
    new_aa_accounts_rows = []
    new_aa_txns_rows = []
    new_mart_rows = []

    # index mart_aa by aa_customer_id if present
    mart_idx = None
    if "aa_customer_id" in mart_aa.columns:
        mart_idx = mart_aa.set_index("aa_customer_id")

    # helper for unique aa_account_id
    max_aa_acct_id = 0
    if "aa_account_id" in aa_accounts.columns:
        try:
            max_aa_acct_id = int(aa_accounts["aa_account_id"].max())
        except Exception:
            max_aa_acct_id = len(aa_accounts)

    # helper for unique aa_txn_id
    max_aa_txn_id = 0
    if "aa_txn_id" in aa_transactions.columns:
        try:
            max_aa_txn_id = int(aa_transactions["aa_txn_id"].max())
        except Exception:
            max_aa_txn_id = len(aa_transactions)

    competitor_codes = ["BANK_A", "BANK_B", "KOTAK"]

    for i, cid in enumerate(new_cust_ids, start=1):
        new_aa_id = max_aa_id + i

        # choose donor aa_customer_id to copy shape
        donor_aa_id = rng.choice(existing_aa_ids)
        donor_maps = aa_customer_map[aa_customer_map["aa_customer_id"] == donor_aa_id]
        donor_accounts = (
            accounts_by_aa.get_group(donor_aa_id) if donor_aa_id in accounts_by_aa else pd.DataFrame()
        )
        donor_txns = (
            txns_by_aa.get_group(donor_aa_id) if donor_aa_id in txns_by_aa else pd.DataFrame()
        )

        # --- AA CUSTOMER MAP rows ---
        for _, dmap in donor_maps.iterrows():
            row = dmap.copy()
            row["aa_customer_id"] = new_aa_id

            # anchor mapping: attach to new core customer
            if row.get("bank_code") == "ANCHOR":
                row["cust_id"] = cid
                # use cif_id from core customer if possible
                # this will be filled later by join if not present
            else:
                # competitor: allow cust_id to be null, but set bank_cif_id unique
                row["cust_id"] = np.nan

            # optional: introduce Kotak bank for some competitor slots
            if row.get("bank_code") in competitor_codes and rng.random() < 0.3:
                row["bank_code"] = "KOTAK"

            new_aa_rows.append(row)

        # --- AA ACCOUNTS rows ---
        if not donor_accounts.empty:
            for _, dacc in donor_accounts.iterrows():
                max_aa_acct_id += 1
                row = dacc.copy()
                row["aa_customer_id"] = new_aa_id
                if "aa_account_id" in row.index:
                    row["aa_account_id"] = max_aa_acct_id

                # fix is_anchor_bank according to bank_code
                if "is_anchor_bank" in row.index and "bank_code" in row.index:
                    row["is_anchor_bank"] = row["bank_code"] == "ANCHOR"

                # core_account_id mapping for anchor accounts
                if row.get("bank_code") == "ANCHOR":
                    acids = new_acid_map.get(cid, [])
                    row["core_account_id"] = acids[0] if acids else np.nan
                else:
                    if "core_account_id" in row.index:
                        row["core_account_id"] = np.nan

                # jitter balances and credit_limit
                for col in ["current_balance", "credit_limit"]:
                    if col in row.index:
                        base = float(row[col])
                        mult = rng.lognormal(mean=0, sigma=0.3)
                        row[col] = max(0.0, base * mult)

                new_aa_accounts_rows.append(row)

        # --- AA TRANSACTIONS rows ---
        if not donor_txns.empty:
            # map donor accounts to new accounts by bank_code + account_type if possible
            for _, dtxn in donor_txns.iterrows():
                max_aa_txn_id += 1
                row = dtxn.copy()
                row["aa_customer_id"] = new_aa_id

                if "aa_txn_id" in row.index:
                    row["aa_txn_id"] = max_aa_txn_id

                # dates jitter
                for dt_col in ["txn_date", "value_date"]:
                    if dt_col in row.index:
                        try:
                            base = pd.to_datetime(row[dt_col])
                            shift = int(rng.integers(-90, 90))
                            row[dt_col] = (base + pd.Timedelta(days=shift)).date()
                        except Exception:
                            pass

                # amount jitter
                for col in ["amount", "txn_amount"]:
                    if col in row.index:
                        base_amt = float(row[col])
                        mult = rng.lognormal(mean=0, sigma=0.3)
                        row[col] = max(0.0, base_amt * mult)

                new_aa_txns_rows.append(row)

        # --- MART 360 row ---
        if mart_idx is not None and new_aa_id not in mart_idx.index:
            if donor_aa_id in mart_idx.index:
                base_row = mart_idx.loc[donor_aa_id].copy()
                base_row["aa_customer_id"] = new_aa_id

                # override key metrics with actual accounts
                # compute from new_aa_accounts_rows for this aa_customer_id
                acc_for_this = [
                    r
                    for r in new_aa_accounts_rows
                    if r.get("aa_customer_id") == new_aa_id
                ]
                if acc_for_this:
                    acc_df = pd.DataFrame(acc_for_this)
                    if "current_balance" in acc_df.columns:
                        total_balance = acc_df["current_balance"].sum()
                        base_row["total_balance_all_banks"] = total_balance

                        if "is_anchor_bank" in acc_df.columns:
                            anchor_bal = acc_df.loc[
                                acc_df["is_anchor_bank"] == True, "current_balance"
                            ].sum()
                            base_row["anchor_balance"] = anchor_bal
                            base_row["competitor_balance"] = total_balance - anchor_bal

                    if "credit_limit" in acc_df.columns:
                        base_row["total_credit_limit"] = acc_df["credit_limit"].sum()

                    base_row["num_accounts"] = len(acc_df)
                    if "bank_code" in acc_df.columns:
                        base_row["num_bank_relationships"] = acc_df["bank_code"].nunique()
                        base_row["num_anchor_accounts"] = (
                            acc_df["is_anchor_bank"].sum()
                            if "is_anchor_bank" in acc_df.columns
                            else np.nan
                        )
                        if "is_anchor_bank" in acc_df.columns:
                            base_row["num_comp_accounts"] = len(
                                acc_df[acc_df["is_anchor_bank"] == False]
                            )

                new_mart_rows.append(base_row)

    # concat new rows
    if new_aa_rows:
        aa_customer_map = pd.concat(
            [aa_customer_map, pd.DataFrame(new_aa_rows)], ignore_index=True
        )
    if new_aa_accounts_rows:
        aa_accounts = pd.concat(
            [aa_accounts, pd.DataFrame(new_aa_accounts_rows)], ignore_index=True
        )
    if new_aa_txns_rows:
        aa_transactions = pd.concat(
            [aa_transactions, pd.DataFrame(new_aa_txns_rows)], ignore_index=True
        )
    if new_mart_rows:
        mart_aa = pd.concat(
            [mart_aa, pd.DataFrame(new_mart_rows)], ignore_index=True
        )

    print(f"[INFO] AA customer_map expanded to {len(aa_customer_map):,} rows")
    print(f"[INFO] AA accounts expanded to {len(aa_accounts):,} rows")
    print(f"[INFO] AA transactions expanded to {len(aa_transactions):,} rows")
    print(f"[INFO] mart_customer_360_aa expanded to {len(mart_aa):,} rows")

    return aa_customer_map, aa_accounts, aa_transactions, mart_aa


# ----------------------------------------------------------------------
# BLOCK F: Lightweight validation
# ----------------------------------------------------------------------


def validate_basic(
    customers: pd.DataFrame,
    target_n: int,
    min_age: int,
    max_age: int,
    min_monthly_income: int,
) -> None:
    print("[INFO] Running basic validation checks")

    # count
    n_cust = customers["cust_id"].nunique()
    if n_cust != target_n:
        print(f"[WARN] Customer count is {n_cust}, expected {target_n}")

    # identify new customers heuristically: last (target_n - original_count) might not be easy
    # Instead, validate constraints globally for all customers with age in [min_age, max_age]
    min_annual = min_monthly_income * 12
    mask_new_like = customers["age"].between(min_age, max_age)
    if "income_annual_inr" in customers.columns:
        income_issues = customers.loc[
            mask_new_like & (customers["income_annual_inr"] < min_annual)
        ]
        if not income_issues.empty:
            print(
                f"[WARN] Found {len(income_issues)} rows age {min_age}-{max_age} "
                f"with annual income < {min_annual}"
            )
        else:
            print(
                "[INFO] All age-eligible customers satisfy income constraint (global check)."
            )

    # uniqueness
    if customers["cust_id"].duplicated().any():
        print("[WARN] Duplicate cust_id found.")
    else:
        print("[INFO] cust_id uniqueness OK.")


# ----------------------------------------------------------------------
# Main CLI orchestration
# ----------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Expand synthetic bank dataset to target users")
    p.add_argument(
        "--input-dir",
        type=str,
        required=True,
        help="Path to original dataset root directory",
    )
    p.add_argument(
        "--output-dir",
        type=str,
        required=True,
        help="Path to save expanded dataset",
    )
    p.add_argument(
        "--target-users",
        type=int,
        default=1000,
        help="Target number of customers/users (default: 1000)",
    )
    p.add_argument(
        "--min-age",
        type=int,
        default=18,
        help="Minimum age for new users (default: 18)",
    )
    p.add_argument(
        "--max-age",
        type=int,
        default=38,
        help="Maximum age for new users (default: 38)",
    )
    p.add_argument(
        "--min-monthly-income",
        type=int,
        default=20000,
        help="Minimum monthly income for new users (default: 20,000)",
    )
    return p.parse_args()


def main() -> None:
    args = parse_args()
    in_root = Path(args.input_dir)
    out_root = Path(args.output_dir)

    # Adjust these if your filenames/paths differ
    path_customers = in_root / "schema_customer_master.csv"
    path_accounts = in_root / "prod_ods_cbsind_general_acct_mast_table.csv"
    path_ans_acc_car = in_root / "ans_acc_car.csv"
    path_hist_tran = in_root / "prod_ods_cbsind_hist_tran_dtl_table.csv"

    aa_root = in_root / "aa_data"
    path_aa_dim_bank = aa_root / "aa_dim_bank.csv"
    path_aa_customer_map = aa_root / "aa_customer_map.csv"
    path_aa_accounts = aa_root / "aa_accounts.csv"
    path_aa_transactions = aa_root / "aa_transactions.csv"
    path_mart_aa = aa_root / "mart_customer_360_aa.csv"

    # OUTPUT paths mirror structure
    out_customers = out_root / "schema_customer_master.csv"
    out_accounts = out_root / "prod_ods_cbsind_general_acct_mast_table.csv"
    out_ans_acc_car = out_root / "ans_acc_car.csv"
    out_hist_tran = out_root / "prod_ods_cbsind_hist_tran_dtl_table.csv"

    aa_out_root = out_root / "aa_data"
    out_aa_dim_bank = aa_out_root / "aa_dim_bank.csv"
    out_aa_customer_map = aa_out_root / "aa_customer_map.csv"
    out_aa_accounts = aa_out_root / "aa_accounts.csv"
    out_aa_transactions = aa_out_root / "aa_transactions.csv"
    out_mart_aa = aa_out_root / "mart_customer_360_aa.csv"

    # ------------------------------------------------------------------
    # Load
    # ------------------------------------------------------------------
    customers = _load_csv(path_customers)
    accounts = _load_csv(path_accounts)

    ans_acc_car = _load_csv(path_ans_acc_car, required=False)
    if ans_acc_car is None:
        ans_acc_car = pd.DataFrame()

    hist_tran = _load_csv(path_hist_tran, required=False)
    if hist_tran is None:
        hist_tran = pd.DataFrame()

    aa_dim_bank = _load_csv(path_aa_dim_bank, required=False)
    if aa_dim_bank is None:
        aa_dim_bank = pd.DataFrame()

    aa_customer_map = _load_csv(path_aa_customer_map, required=False)
    if aa_customer_map is None:
        aa_customer_map = pd.DataFrame()

    aa_accounts = _load_csv(path_aa_accounts, required=False)
    if aa_accounts is None:
        aa_accounts = pd.DataFrame()

    aa_transactions = _load_csv(path_aa_transactions, required=False)
    if aa_transactions is None:
        aa_transactions = pd.DataFrame()

    mart_aa = _load_csv(path_mart_aa, required=False)
    if mart_aa is None:
        mart_aa = pd.DataFrame()


    # record original customers for mapping
    customers_before = set(customers["cust_id"].astype(str).unique())

    # ------------------------------------------------------------------
    # BLOCK A: expand customers
    # ------------------------------------------------------------------
    customers_expanded = expand_customers(
        customers,
        target_n=args.target_users,
        min_age=args.min_age,
        max_age=args.max_age,
        min_monthly_income=args.min_monthly_income,
    )
    customers_after = set(customers_expanded["cust_id"].astype(str).unique())

    # ------------------------------------------------------------------
    # BLOCK B: expand core accounts & ans_acc_car
    # ------------------------------------------------------------------
    accounts_expanded, new_acid_map = expand_core_accounts(
        accounts, customers_before, customers_after
    )

    if not ans_acc_car.empty:
        ans_acc_car_expanded = expand_ans_acc_car(
            ans_acc_car, customers_before, customers_after
        )
    else:
        ans_acc_car_expanded = ans_acc_car

    # ------------------------------------------------------------------
    # BLOCK C: expand core transactions
    # ------------------------------------------------------------------
    if not hist_tran.empty:
        hist_tran_expanded = expand_hist_tran(
            hist_tran, accounts, accounts_expanded, new_acid_map
        )
    else:
        hist_tran_expanded = hist_tran

    # ------------------------------------------------------------------
    # BLOCK D: update AA bank mapping
    # ------------------------------------------------------------------
    if not aa_dim_bank.empty:
        aa_dim_bank_updated = update_aa_dim_bank(aa_dim_bank)
    else:
        aa_dim_bank_updated = aa_dim_bank

    # ------------------------------------------------------------------
    # BLOCK E: expand AA layer
    # ------------------------------------------------------------------
    if not aa_customer_map.empty and not aa_accounts.empty and not mart_aa.empty:
        (
            aa_customer_map_expanded,
            aa_accounts_expanded,
            aa_transactions_expanded,
            mart_aa_expanded,
        ) = expand_aa_customers_and_accounts(
            aa_customer_map,
            aa_accounts,
            aa_transactions,
            mart_aa,
            customers_before,
            customers_after,
            new_acid_map,
        )
    else:
        aa_customer_map_expanded = aa_customer_map
        aa_accounts_expanded = aa_accounts
        aa_transactions_expanded = aa_transactions
        mart_aa_expanded = mart_aa

    # ------------------------------------------------------------------
    # BLOCK F: validation
    # ------------------------------------------------------------------
    validate_basic(
        customers_expanded,
        target_n=args.target_users,
        min_age=args.min_age,
        max_age=args.max_age,
        min_monthly_income=args.min_monthly_income,
    )

    # ------------------------------------------------------------------
    # Save all expanded artifacts
    # ------------------------------------------------------------------
    _save_csv(customers_expanded, out_customers)
    _save_csv(accounts_expanded, out_accounts)

    if not ans_acc_car_expanded.empty:
        _save_csv(ans_acc_car_expanded, out_ans_acc_car)

    if not hist_tran_expanded.empty:
        _save_csv(hist_tran_expanded, out_hist_tran)

    if not aa_dim_bank_updated.empty:
        _save_csv(aa_dim_bank_updated, out_aa_dim_bank)

    if not aa_customer_map_expanded.empty:
        _save_csv(aa_customer_map_expanded, out_aa_customer_map)

    if not aa_accounts_expanded.empty:
        _save_csv(aa_accounts_expanded, out_aa_accounts)

    if not aa_transactions_expanded.empty:
        _save_csv(aa_transactions_expanded, out_aa_transactions)

    if not mart_aa_expanded.empty:
        _save_csv(mart_aa_expanded, out_mart_aa)

    print("[INFO] Expansion complete. Expanded dataset written to:", out_root)


if __name__ == "__main__":
    main()


